#pragma once

void InitFullScreenQuad();

void DrawFullScreenQuad();
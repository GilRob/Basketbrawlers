#pragma once

void SeedRandomNumberGenerator();
void SeedRandomNumberGenerator(unsigned int seed);

float RandomRangef(float min, float max);
int RandomRangei(int min, int max);
